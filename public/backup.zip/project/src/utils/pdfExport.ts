import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { supabase } from '../lib/supabase';
import { PDFDocument } from 'pdf-lib';

type Language = 'nl' | 'en' | 'de';

const translations = {
  nl: {
    internalReport: 'Intern taxatierapport',
    generatedOn: 'Gegenereerd op',
    generalInfo: 'Algemene informatie',
    dossierNumber: 'Dossiernummer',
    title: 'Titel',
    equipmentType: 'Type apparatuur',
    brand: 'Merk',
    model: 'Model',
    buildYear: 'Bouwjaar',
    condition: 'Conditie',
    location: 'Locatie',
    estimatedValue: 'Geschatte waarde',
    status: 'Status',
    createdBy: 'Aangemaakt door',
    createdOn: 'Aangemaakt op',
    internalRemarks: 'Interne opmerkingen',
    description: 'Omschrijving',
    technicalSpecs: 'Technische specificaties',
    technicalSpecsForklift: 'Technische specificaties (Heftruck)',
    stockId: 'Stock ID',
    serialNumber: 'Serienummer',
    capacity: 'Capaciteit',
    loadCenter: 'Lastcentrum',
    readRunningHours: 'Afgelezen urenstand',
    mast: 'Mast',
    liftHeight: 'Hefhoogte',
    cabinType: 'Cabinetype',
    engineBrand: 'Motor merk',
    engineType: 'Motor type',
    bids: 'Biedingen',
    dealer: 'Dealer',
    amount: 'Bedrag',
    noAmount: 'Geen bedrag',
    date: 'Datum',
    photos: "Foto's",
    excellent: 'Uitstekend',
    good: 'Goed',
    fair: 'Redelijk',
    poor: 'Slecht',
    draft: 'Concept',
    open: 'Open',
    stock: 'Stock',
    biddingActive: 'Bieden actief',
    sold: 'Verkocht',
    archived: 'Gearchiveerd',
    pending: 'In behandeling',
    submitted: 'Ingediend',
    accepted: 'Geaccepteerd',
    rejected: 'Afgewezen',
  },
  en: {
    internalReport: 'Internal Valuation Report',
    generatedOn: 'Generated on',
    generalInfo: 'General Information',
    dossierNumber: 'Dossier Number',
    title: 'Title',
    equipmentType: 'Equipment Type',
    brand: 'Brand',
    model: 'Model',
    buildYear: 'Build Year',
    condition: 'Condition',
    location: 'Location',
    estimatedValue: 'Estimated Value',
    status: 'Status',
    createdBy: 'Created By',
    createdOn: 'Created On',
    internalRemarks: 'Internal Remarks',
    description: 'Description',
    technicalSpecs: 'Technical Specifications',
    technicalSpecsForklift: 'Technical Specifications (Forklift)',
    stockId: 'Stock ID',
    serialNumber: 'Serial Number',
    capacity: 'Capacity',
    loadCenter: 'Load Center',
    readRunningHours: 'Read running hours',
    mast: 'Mast',
    liftHeight: 'Lifting height',
    cabinType: 'Cabin Type',
    engineBrand: 'Engine Brand',
    engineType: 'Engine Type',
    bids: 'Bids',
    dealer: 'Dealer',
    amount: 'Amount',
    noAmount: 'No amount',
    date: 'Date',
    photos: 'Photos',
    excellent: 'Excellent',
    good: 'Good',
    fair: 'Fair',
    poor: 'Poor',
    draft: 'Draft',
    open: 'Open',
    stock: 'Stock',
    biddingActive: 'Bidding Active',
    sold: 'Sold',
    archived: 'Archived',
    pending: 'Pending',
    submitted: 'Submitted',
    accepted: 'Accepted',
    rejected: 'Rejected',
  },
  de: {
    internalReport: 'Interner Bewertungsbericht',
    generatedOn: 'Erstellt am',
    generalInfo: 'Allgemeine Informationen',
    dossierNumber: 'Dossiernummer',
    title: 'Titel',
    equipmentType: 'Gerätetyp',
    brand: 'Marke',
    model: 'Modell',
    buildYear: 'Baujahr',
    condition: 'Zustand',
    location: 'Standort',
    estimatedValue: 'Geschätzter Wert',
    status: 'Status',
    createdBy: 'Erstellt von',
    createdOn: 'Erstellt am',
    internalRemarks: 'Interne Bemerkungen',
    description: 'Beschreibung',
    technicalSpecs: 'Technische Spezifikationen',
    technicalSpecsForklift: 'Technische Spezifikationen (Stapler)',
    stockId: 'Stock ID',
    serialNumber: 'Seriennummer',
    capacity: 'Kapazität',
    loadCenter: 'Lastschwerpunkt',
    readRunningHours: 'abgelesene Stundenzahl',
    mast: 'Mast',
    liftHeight: 'Hubhöhe',
    cabinType: 'Kabinentyp',
    engineBrand: 'Motormarke',
    engineType: 'Motortyp',
    bids: 'Gebote',
    dealer: 'Händler',
    amount: 'Betrag',
    noAmount: 'Kein Betrag',
    date: 'Datum',
    photos: 'Fotos',
    excellent: 'Ausgezeichnet',
    good: 'Gut',
    fair: 'Angemessen',
    poor: 'Schlecht',
    draft: 'Entwurf',
    open: 'Offen',
    stock: 'Lager',
    biddingActive: 'Bieten aktiv',
    sold: 'Verkauft',
    archived: 'Archiviert',
    pending: 'Ausstehend',
    submitted: 'Eingereicht',
    accepted: 'Akzeptiert',
    rejected: 'Abgelehnt',
  },
};

interface DossierData {
  id: string;
  dossier_number: string;
  title: string;
  description: string;
  equipment_type: string;
  brand: string;
  model: string;
  year: number | null;
  condition: string;
  location: string;
  estimated_value: number | null;
  status: string;
  created_at: string;
  user_profiles?: {
    full_name: string;
  };
}

interface ForkliftDetails {
  order_no?: string;
  date?: string;
  brand?: string;
  type?: string;
  power?: string;
  capacity_kg?: number;
  load_center_mm?: number;
  year_of_manufacture?: number;
  hours_on_clock?: number;
  mast?: string;
  mast_type?: string;
  free_lift?: string;
  lift_height_mm?: number;
  serial_no?: string;
  attachment?: string;
  attachment_other?: string;
  remark?: string;
  length_total_mm?: number;
  width_total_mm?: number;
  drive_through_height_mm?: number;
  serviceweight_kg?: number;
  cabin_type?: string;
  heater?: boolean;
  airco?: boolean;
  streetlights_front?: string;
  streetlights_rear?: string;
  work_light_front?: string;
  work_light_rear?: string;
  beacon?: string;
  radio?: string;
  extra_lights?: string;
  extra_lights_2?: string;
  wheelbase?: string;
  mirrors?: string;
  mirrors_heated?: boolean;
  seat_brand?: string;
  seat_type_suspension?: string;
  headrest?: string;
  seat_options?: string;
  engine_brand?: string;
  engine_type?: string;
  engine_remark?: string;
  front_axle_brand?: string;
  front_axle_type?: string;
  front_axle_remark?: string;
  trans_brand?: string;
  trans_type?: string;
  trans_remark?: string;
  shift_type?: string;
  adblue?: boolean;
  particle_filter?: string;
  forks_length_mm?: number;
  forks_width_mm?: number;
  forks_thickness_mm?: number;
  forks_spread_min_mm?: number;
  forks_spread_max_mm?: number;
  no_forks?: boolean;
  hydraulic_lines?: number;
  tires_front?: string;
  tires_front_brand?: string;
  tires_rear?: string;
  tires_rear_brand?: string;
}

interface Photo {
  id: string;
  storage_path: string;
  filename: string;
}

interface Bid {
  id: string;
  bedrag: number | null;
  amount: number | null;
  valuta: string;
  status: string;
  notitie: string | null;
  notes: string | null;
  created_at: string;
  dealers?: {
    name: string;
  };
}

const getStatusLabel = (status: string, lang: Language) => {
  const t = translations[lang];
  const labels: Record<string, string> = {
    draft: t.draft,
    open: t.open,
    stock: t.stock,
    bidding: t.biddingActive,
    sold: t.sold,
    archived: t.archived,
  };
  return labels[status] || status;
};

const getConditionLabel = (condition: string, lang: Language) => {
  const t = translations[lang];
  const labels: Record<string, string> = {
    excellent: t.excellent,
    good: t.good,
    fair: t.fair,
    poor: t.poor,
  };
  return labels[condition] || condition;
};

const getEquipmentTypeLabel = (type: string, lang: Language) => {
  const equipmentLabels: Record<string, Record<Language, string>> = {
    container: { nl: 'Container', en: 'Container', de: 'Container' },
    trailer: { nl: 'Trailer', en: 'Trailer', de: 'Anhänger' },
    chassis: { nl: 'Chassis', en: 'Chassis', de: 'Fahrgestell' },
    heavy_duty_forklift: { nl: 'Heftrucks zwaar', en: 'Heavy Duty Forklift', de: 'Schwerlaststapler' },
    other: { nl: 'Overig', en: 'Other', de: 'Sonstige' },
  };
  return equipmentLabels[type]?.[lang] || type;
};

async function compressImage(dataUrl: string, maxWidth: number = 1920, maxHeight: number = 1920, quality: number = 0.82): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let { width, height } = img;

      if (width > maxWidth || height > maxHeight) {
        const aspectRatio = width / height;
        if (width > height) {
          width = maxWidth;
          height = maxWidth / aspectRatio;
        } else {
          height = maxHeight;
          width = maxHeight * aspectRatio;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Could not get canvas context'));
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);

      const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
      resolve(compressedDataUrl);
    };
    img.onerror = reject;
    img.src = dataUrl;
  });
}

async function addLogoToPage(doc: jsPDF, logoDataUrl: string) {
  try {
    const img = new Image();
    img.src = logoDataUrl;
    await new Promise((resolve) => {
      img.onload = resolve;
    });

    const logoMaxWidth = 40;
    const logoMaxHeight = 20;
    const aspectRatio = img.width / img.height;

    let logoWidth = logoMaxWidth;
    let logoHeight = logoMaxWidth / aspectRatio;

    if (logoHeight > logoMaxHeight) {
      logoHeight = logoMaxHeight;
      logoWidth = logoMaxHeight * aspectRatio;
    }

    doc.addImage(logoDataUrl, 'JPEG', 150, 10, logoWidth, logoHeight);
  } catch (error) {
    console.error('Error adding logo to page:', error);
  }
}

function addFooter(doc: jsPDF, logoDataUrl?: string) {
  const pageCount = doc.getNumberOfPages();

  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);

    if (logoDataUrl && i > 1) {
      try {
        const img = new Image();
        img.src = logoDataUrl;

        const logoMaxWidth = 30;
        const logoMaxHeight = 15;
        const aspectRatio = img.width / img.height;

        let logoWidth = logoMaxWidth;
        let logoHeight = logoMaxWidth / aspectRatio;

        if (logoHeight > logoMaxHeight) {
          logoHeight = logoMaxHeight;
          logoWidth = logoMaxHeight * aspectRatio;
        }

        doc.addImage(logoDataUrl, 'JPEG', 160, 5, logoWidth, logoHeight);
      } catch (error) {
        console.error('Error adding logo to page:', error);
      }
    }

    doc.setFontSize(7);
    doc.setTextColor(100, 116, 139);

    const footerY = 285;
    const lineHeight = 3;

    doc.setDrawColor(226, 232, 240);
    doc.line(20, footerY - 3, 190, footerY - 3);

    doc.setFont('helvetica', 'bold');
    doc.text('Heavy Cargo Lifters', 20, footerY);

    doc.setFont('helvetica', 'normal');
    doc.text('info@heavycargolifters.com', 20, footerY + lineHeight);
    doc.text('www.heavycargolifters.com', 20, footerY + lineHeight * 2);

    doc.text('VAT Number: NL003846032B41', 85, footerY);
    doc.text('Chamber of commerce: 89251113', 85, footerY + lineHeight);

    doc.text('Bank Swift/BIC: ABN Amro', 145, footerY);
    doc.text('NL93ABNA0119446626', 145, footerY + lineHeight);
  }
}

export async function generateDossierPDF(dossierId: string, language: Language = 'nl') {
  try {
    const t = translations[language];
    const { data: dossier, error: dossierError } = await supabase
      .from('dossiers')
      .select(`
        *,
        user_profiles:created_by (
          full_name
        )
      `)
      .eq('id', dossierId)
      .maybeSingle();

    if (dossierError) throw dossierError;
    if (!dossier) throw new Error('Dossier niet gevonden');

    const { data: forkliftDetails } = await supabase
      .from('forklift_details')
      .select('*')
      .eq('dossier_id', dossierId)
      .maybeSingle();

    const { data: photos } = await supabase
      .from('photos')
      .select('*')
      .eq('dossier_id', dossierId)
      .eq('visible_online', true)
      .order('display_order', { ascending: true })
      .order('created_at', { ascending: true });

    const { data: bids } = await supabase
      .from('bids')
      .select(`
        *,
        dealers (
          name
        )
      `)
      .eq('dossier_id', dossierId)
      .order('created_at', { ascending: false });

    const doc = new jsPDF();
    let yPosition = 20;
    let compressedLogo: string | null = null;

    try {
      const logoResponse = await fetch('/hclifters.jpg');
      const logoBlob = await logoResponse.blob();
      const logoDataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(logoBlob);
      });

      compressedLogo = await compressImage(logoDataUrl, 800, 800, 0.85);

      const img = new Image();
      img.src = compressedLogo;
      await new Promise((resolve) => {
        img.onload = resolve;
      });

      const logoMaxWidth = 50;
      const logoMaxHeight = 25;
      const aspectRatio = img.width / img.height;

      let logoWidth = logoMaxWidth;
      let logoHeight = logoMaxWidth / aspectRatio;

      if (logoHeight > logoMaxHeight) {
        logoHeight = logoMaxHeight;
        logoWidth = logoMaxHeight * aspectRatio;
      }

      doc.addImage(compressedLogo, 'JPEG', 145, 10, logoWidth, logoHeight);
    } catch (error) {
      console.error('Error loading logo:', error);
    }

    doc.setFontSize(24);
    doc.setTextColor(15, 23, 42);
    doc.text(t.internalReport, 20, yPosition);
    yPosition += 15;

    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    const locale = language === 'de' ? 'de-DE' : language === 'en' ? 'en-GB' : 'nl-NL';
    doc.text(`${t.generatedOn}: ${new Date().toLocaleDateString(locale)}`, 20, yPosition);
    yPosition += 15;

    const frontPhoto = photos?.find(p =>
      p.category?.toLowerCase().includes('voorkant') ||
      p.category?.toLowerCase().includes('front')
    ) || photos?.[0];

    if (frontPhoto) {
      try {
        const { data } = supabase.storage
          .from('dossier-photos')
          .getPublicUrl(frontPhoto.storage_path);

        const response = await fetch(data.publicUrl);
        const blob = await response.blob();
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        });

        const compressedPhoto = await compressImage(dataUrl);

        const imageWidth = 170;
        const imageHeight = 120;
        const imageX = 20;

        doc.addImage(compressedPhoto, 'JPEG', imageX, yPosition, imageWidth, imageHeight);
        yPosition += imageHeight + 10;
      } catch (error) {
        console.error('Error loading front photo:', error);
      }
    }

    doc.setFontSize(16);
    doc.setTextColor(15, 23, 42);
    doc.text(t.generalInfo, 20, yPosition);
    yPosition += 10;

    const generalData = [
      [t.dossierNumber, dossier.dossier_number],
      [t.title, dossier.title],
      [t.equipmentType, getEquipmentTypeLabel(dossier.equipment_type, language)],
      [t.brand, dossier.brand || '-'],
      [t.model, dossier.model || '-'],
      [t.buildYear, dossier.year?.toString() || '-'],
      [t.condition, getConditionLabel(dossier.condition, language)],
      [t.location, dossier.location || '-'],
      [t.estimatedValue, dossier.estimated_value ? `€ ${dossier.estimated_value.toLocaleString(locale)}` : '-'],
      [t.status, getStatusLabel(dossier.status, language)],
      [t.createdBy, dossier.user_profiles?.full_name || '-'],
      [t.createdOn, new Date(dossier.created_at).toLocaleDateString(locale)],
      ...(forkliftDetails?.remark ? [[t.internalRemarks, forkliftDetails.remark]] : []),
    ];

    autoTable(doc, {
      startY: yPosition,
      head: [],
      body: generalData,
      theme: 'plain',
      styles: {
        fontSize: 10,
        cellPadding: 3,
      },
      columnStyles: {
        0: { fontStyle: 'bold', textColor: [71, 85, 105], cellWidth: 50 },
        1: { textColor: [15, 23, 42] },
      },
    });

    yPosition = (doc as any).lastAutoTable.finalY + 15;

    if (dossier.description) {
      if (yPosition > 250) {
        doc.addPage();
        yPosition = 20;
      }

      doc.setFontSize(16);
      doc.setTextColor(15, 23, 42);
      doc.text(t.description, 20, yPosition);
      yPosition += 8;

      doc.setFontSize(10);
      doc.setTextColor(51, 65, 85);
      const splitDescription = doc.splitTextToSize(dossier.description, 170);
      doc.text(splitDescription, 20, yPosition);
      yPosition += splitDescription.length * 5 + 10;
    }

    if (forkliftDetails) {
      if (yPosition > 250) {
        doc.addPage();
        yPosition = 20;
      }

      doc.setFontSize(16);
      doc.setTextColor(15, 23, 42);
      doc.text(t.technicalSpecsForklift, 20, yPosition);
      yPosition += 10;

      const technicalData: string[][] = [];
      const hoursUnit = language === 'de' ? 'Std.' : language === 'en' ? 'hrs' : 'uur';

      console.log('=== GENERATING PDF WITH FORKLIFT DETAILS ===');
      console.log('Forklift details:', forkliftDetails);

      if (forkliftDetails.order_no) technicalData.push([t.stockId, forkliftDetails.order_no]);
      if (forkliftDetails.serial_no) technicalData.push([t.serialNumber, forkliftDetails.serial_no]);
      if (forkliftDetails.power) technicalData.push(['Brandstof', forkliftDetails.power]);
      if (forkliftDetails.capacity_kg) technicalData.push([t.capacity, `${forkliftDetails.capacity_kg.toLocaleString(locale)} kg`]);
      if (forkliftDetails.load_center_mm) technicalData.push([t.loadCenter, `${forkliftDetails.load_center_mm.toLocaleString(locale)} mm`]);
      if (forkliftDetails.hours_on_clock) technicalData.push([t.readRunningHours, `${forkliftDetails.hours_on_clock.toLocaleString(locale)} ${hoursUnit}`]);
      if (forkliftDetails.mast) technicalData.push([t.mast, forkliftDetails.mast]);
      if (forkliftDetails.mast_type) technicalData.push(['Masttype', forkliftDetails.mast_type]);
      if (forkliftDetails.lift_height_mm) technicalData.push([t.liftHeight, `${forkliftDetails.lift_height_mm.toLocaleString(locale)} mm`]);
      if (forkliftDetails.cabin_type) technicalData.push([t.cabinType, forkliftDetails.cabin_type]);
      if (forkliftDetails.engine_brand) technicalData.push([t.engineBrand, forkliftDetails.engine_brand]);
      if (forkliftDetails.engine_type) technicalData.push([t.engineType, forkliftDetails.engine_type]);
      if (forkliftDetails.trans_brand) technicalData.push(['Transmissie merk', forkliftDetails.trans_brand]);
      if (forkliftDetails.trans_type) technicalData.push(['Transmissie type', forkliftDetails.trans_type]);
      if (forkliftDetails.hydraulic_lines) technicalData.push(['Hydraulische leidingen', forkliftDetails.hydraulic_lines.toString()]);
      if (forkliftDetails.attachment) technicalData.push(['Aanbouwdeel', forkliftDetails.attachment]);
      if (forkliftDetails.adblue !== null && forkliftDetails.adblue !== undefined) technicalData.push(['AdBlue', forkliftDetails.adblue ? 'Ja' : 'Nee']);
      if (forkliftDetails.radio !== null && forkliftDetails.radio !== undefined) technicalData.push(['Radio', forkliftDetails.radio ? 'Ja' : 'Nee']);

      console.log('Technical data rows:', technicalData.length);
      console.log('Technical data:', technicalData);

      if (technicalData.length > 0) {
        autoTable(doc, {
          startY: yPosition,
          head: [],
          body: technicalData,
          theme: 'plain',
          styles: {
            fontSize: 9,
            cellPadding: 2,
          },
          columnStyles: {
            0: { fontStyle: 'bold', textColor: [71, 85, 105], cellWidth: 50 },
            1: { textColor: [15, 23, 42] },
          },
        });

        yPosition = (doc as any).lastAutoTable.finalY + 15;
      }
    }

    if (bids && bids.length > 0) {
      if (yPosition > 230) {
        doc.addPage();
        yPosition = 20;
      }

      doc.setFontSize(16);
      doc.setTextColor(15, 23, 42);
      doc.text(t.bids, 20, yPosition);
      yPosition += 10;

      const bidsData = bids.map((bid: Bid) => {
        const amount = bid.amount || bid.bedrag;
        const statusLabel = bid.status === 'pending' ? t.pending :
                           bid.status === 'submitted' ? t.submitted :
                           bid.status === 'accepted' ? t.accepted : t.rejected;
        return [
          bid.dealers?.name || '-',
          amount ? `€ ${amount.toLocaleString(locale)}` : t.noAmount,
          statusLabel,
          new Date(bid.created_at).toLocaleDateString(locale),
        ];
      });

      autoTable(doc, {
        startY: yPosition,
        head: [[t.dealer, t.amount, t.status, t.date]],
        body: bidsData,
        theme: 'striped',
        headStyles: {
          fillColor: [51, 65, 85],
          textColor: [255, 255, 255],
          fontStyle: 'bold',
        },
        styles: {
          fontSize: 9,
          cellPadding: 3,
        },
      });

      yPosition = (doc as any).lastAutoTable.finalY + 15;
    }

    if (photos && photos.length > 0) {
      doc.addPage();
      yPosition = 20;

      doc.setFontSize(16);
      doc.setTextColor(15, 23, 42);
      doc.text(t.photos, 20, yPosition);
      yPosition += 10;

      const imagePromises = photos.map(async (photo: Photo) => {
        try {
          const { data } = supabase.storage
            .from('dossier-photos')
            .getPublicUrl(photo.storage_path);

          const response = await fetch(data.publicUrl);
          const blob = await response.blob();
          const dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });

          const compressed = await compressImage(dataUrl);
          return compressed;
        } catch (error) {
          console.error('Error loading photo:', error);
          return null;
        }
      });

      const imageDataUrls = await Promise.all(imagePromises);
      const validImages = imageDataUrls.filter(url => url !== null) as string[];

      let xPos = 20;
      let yPos = Math.max(yPosition, 25);
      const imageWidth = 80;
      const imageHeight = 60;
      const spacing = 10;
      const footerStartY = 282;
      const maxYForImages = footerStartY - imageHeight - 10;
      let imagesInRow = 0;

      validImages.forEach((imageData, index) => {
        if (imagesInRow === 2) {
          xPos = 20;
          yPos += imageHeight + spacing;
          imagesInRow = 0;
        }

        if (yPos > maxYForImages) {
          doc.addPage();
          yPos = 25;
          xPos = 20;
          imagesInRow = 0;
        }

        try {
          doc.addImage(imageData, 'JPEG', xPos, yPos, imageWidth, imageHeight);
        } catch (error) {
          console.error('Error adding image to PDF:', error);
        }

        xPos += imageWidth + spacing;
        imagesInRow++;
      });
    }

    addFooter(doc, compressedLogo || undefined);

    const brand = dossier.brand || 'Unknown';
    const model = dossier.model || 'Unknown';
    const filename = `Intern-Taxatierapport-${dossier.dossier_number}_${brand}_${model}.pdf`.replace(/\s+/g, '_');
    doc.save(filename);
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw error;
  }
}

export async function generateExternalDossierPDF(dossierId: string, language: Language = 'nl') {
  try {
    const t = translations[language];
    const locale = language === 'de' ? 'de-DE' : language === 'en' ? 'en-GB' : 'nl-NL';
    const { data: dossier, error: dossierError } = await supabase
      .from('dossiers')
      .select(`
        *,
        user_profiles:created_by (
          full_name
        )
      `)
      .eq('id', dossierId)
      .maybeSingle();

    if (dossierError) throw dossierError;
    if (!dossier) throw new Error('Dossier niet gevonden');

    const { data: forkliftDetails } = await supabase
      .from('forklift_details')
      .select('*')
      .eq('dossier_id', dossierId)
      .maybeSingle();

    const { data: echDetails } = await supabase
      .from('empty_container_handler_details')
      .select('*')
      .eq('dossier_id', dossierId)
      .maybeSingle();

    const { data: reachstackerDetails } = await supabase
      .from('reachstacker_details')
      .select('*')
      .eq('dossier_id', dossierId)
      .maybeSingle();

    const { data: terminalTractorDetails } = await supabase
      .from('terminal_tractor_details')
      .select('*')
      .eq('dossier_id', dossierId)
      .maybeSingle();

    const { data: photos } = await supabase
      .from('photos')
      .select('*')
      .eq('dossier_id', dossierId)
      .eq('visible_online', true)
      .order('display_order', { ascending: true })
      .order('created_at', { ascending: true });

    const doc = new jsPDF();
    let yPosition = 20;
    let compressedLogo: string | null = null;

    try {
      const logoResponse = await fetch('/hclifters.jpg');
      const logoBlob = await logoResponse.blob();
      const logoDataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(logoBlob);
      });

      compressedLogo = await compressImage(logoDataUrl, 800, 800, 0.85);

      const img = new Image();
      img.src = compressedLogo;
      await new Promise((resolve) => {
        img.onload = resolve;
      });

      const logoMaxWidth = 50;
      const logoMaxHeight = 25;
      const aspectRatio = img.width / img.height;

      let logoWidth = logoMaxWidth;
      let logoHeight = logoMaxWidth / aspectRatio;

      if (logoHeight > logoMaxHeight) {
        logoHeight = logoMaxHeight;
        logoWidth = logoMaxHeight * aspectRatio;
      }

      doc.addImage(compressedLogo, 'JPEG', 145, 10, logoWidth, logoHeight);
    } catch (error) {
      console.error('Error loading logo:', error);
    }

    doc.setFontSize(28);
    doc.setTextColor(15, 23, 42);
    const brandModel = `${dossier.brand || ''} ${dossier.model || ''}`.trim();
    doc.text(brandModel, 20, yPosition);
    yPosition += 15;

    const frontPhoto = photos?.find(p =>
      p.category?.toLowerCase().includes('voorkant') ||
      p.category?.toLowerCase().includes('front')
    ) || photos?.[0];

    if (frontPhoto) {
      try {
        const { data } = supabase.storage
          .from('dossier-photos')
          .getPublicUrl(frontPhoto.storage_path);

        const response = await fetch(data.publicUrl);
        const blob = await response.blob();
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        });

        const compressedPhoto = await compressImage(dataUrl);

        const imageWidth = 170;
        const imageHeight = 120;
        const imageX = 20;

        doc.addImage(compressedPhoto, 'JPEG', imageX, yPosition, imageWidth, imageHeight);
        yPosition += imageHeight + 10;
      } catch (error) {
        console.error('Error loading front photo:', error);
      }
    }

    const detailsToUse = forkliftDetails || echDetails || reachstackerDetails || terminalTractorDetails;

    if (detailsToUse) {
      doc.setFontSize(16);
      doc.setTextColor(15, 23, 42);
      doc.text(t.technicalSpecs, 20, yPosition);
      yPosition += 10;

      const technicalData: string[][] = [];
      const hoursUnit = language === 'de' ? 'Std.' : language === 'en' ? 'hrs' : 'uur';
      const yesNo = (value: boolean | undefined) => {
        if (value === undefined || value === null) return '';
        return value ? (language === 'de' ? 'Ja' : language === 'en' ? 'Yes' : 'Ja') : (language === 'de' ? 'Nein' : language === 'en' ? 'No' : 'Nee');
      };

      // Basic specifications (common for all types)
      if (detailsToUse.order_no) technicalData.push([t.stockId, detailsToUse.order_no]);
      if (detailsToUse.serial_no) technicalData.push([t.serialNumber, detailsToUse.serial_no]);
      if (detailsToUse.brand) technicalData.push([t.brand, detailsToUse.brand]);
      if (detailsToUse.type) technicalData.push([t.model, detailsToUse.type]);
      if (detailsToUse.year_of_manufacture) technicalData.push([t.buildYear, detailsToUse.year_of_manufacture.toString()]);
      if (detailsToUse.power) technicalData.push([language === 'de' ? 'Antrieb' : language === 'en' ? 'Power' : 'Aandrijving', detailsToUse.power]);

      // Capacity & dimensions
      if (detailsToUse.capacity_kg) technicalData.push([t.capacity, `${detailsToUse.capacity_kg.toLocaleString(locale)} kg`]);
      if (detailsToUse.load_center_mm) technicalData.push([t.loadCenter, `${detailsToUse.load_center_mm.toLocaleString(locale)} mm`]);
      if (detailsToUse.hours_on_clock) technicalData.push([t.readRunningHours, `${detailsToUse.hours_on_clock.toLocaleString(locale)} ${hoursUnit}`]);

      // Mast information
      if (detailsToUse.mast) technicalData.push([t.mast, detailsToUse.mast]);
      if (detailsToUse.mast_type) technicalData.push([language === 'de' ? 'Masttyp' : language === 'en' ? 'Mast Type' : 'Masttype', detailsToUse.mast_type]);
      if (detailsToUse.free_lift) technicalData.push([language === 'de' ? 'Freihub' : language === 'en' ? 'Free Lift' : 'Vrijheffing', detailsToUse.free_lift]);
      if (detailsToUse.lift_height_mm) technicalData.push([t.liftHeight, `${detailsToUse.lift_height_mm.toLocaleString(locale)} mm`]);

      // Physical dimensions
      if (detailsToUse.length_total_mm) technicalData.push([language === 'de' ? 'Gesamtlänge' : language === 'en' ? 'Total Length' : 'Totale lengte', `${detailsToUse.length_total_mm.toLocaleString(locale)} mm`]);
      if (detailsToUse.width_total_mm) technicalData.push([language === 'de' ? 'Gesamtbreite' : language === 'en' ? 'Total Width' : 'Totale breedte', `${detailsToUse.width_total_mm.toLocaleString(locale)} mm`]);
      if (detailsToUse.drive_through_height_mm) technicalData.push([language === 'de' ? 'Durchfahrtshöhe' : language === 'en' ? 'Drive-through Height' : 'Doorrijhoogte', `${detailsToUse.drive_through_height_mm.toLocaleString(locale)} mm`]);
      if (detailsToUse.serviceweight_kg) technicalData.push([language === 'de' ? 'Eigengewicht' : language === 'en' ? 'Service Weight' : 'Eigen gewicht', `${detailsToUse.serviceweight_kg.toLocaleString(locale)} kg`]);

      // Cabin & comfort
      if (detailsToUse.cabin_type) technicalData.push([t.cabinType, detailsToUse.cabin_type]);
      if (detailsToUse.heater !== undefined && detailsToUse.heater !== null) technicalData.push([language === 'de' ? 'Heizung' : language === 'en' ? 'Heater' : 'Verwarming', yesNo(detailsToUse.heater)]);
      if (detailsToUse.airco !== undefined && detailsToUse.airco !== null) technicalData.push([language === 'de' ? 'Klimaanlage' : language === 'en' ? 'Air Conditioning' : 'Airconditioning', yesNo(detailsToUse.airco)]);

      // Seat information
      if (detailsToUse.seat_brand) technicalData.push([language === 'de' ? 'Sitzmarke' : language === 'en' ? 'Seat Brand' : 'Stoelmerk', detailsToUse.seat_brand]);
      if (detailsToUse.seat_type_suspension) technicalData.push([language === 'de' ? 'Sitzfederung' : language === 'en' ? 'Seat Suspension' : 'Stoelvering', detailsToUse.seat_type_suspension]);

      // Engine
      if (detailsToUse.engine_brand) technicalData.push([t.engineBrand, detailsToUse.engine_brand]);
      if (detailsToUse.engine_type) technicalData.push([t.engineType, detailsToUse.engine_type]);
      if (detailsToUse.adblue !== undefined && detailsToUse.adblue !== null) technicalData.push(['AdBlue', yesNo(detailsToUse.adblue)]);

      // Axles & transmission
      if (detailsToUse.front_axle_brand) technicalData.push([language === 'de' ? 'Vorderachsmarke' : language === 'en' ? 'Front Axle Brand' : 'Vooras merk', detailsToUse.front_axle_brand]);
      if (detailsToUse.front_axle_type) technicalData.push([language === 'de' ? 'Vorderachstyp' : language === 'en' ? 'Front Axle Type' : 'Vooras type', detailsToUse.front_axle_type]);
      if (detailsToUse.trans_brand) technicalData.push([language === 'de' ? 'Getriebemarke' : language === 'en' ? 'Transmission Brand' : 'Transmissie merk', detailsToUse.trans_brand]);
      if (detailsToUse.trans_type) technicalData.push([language === 'de' ? 'Getriebetyp' : language === 'en' ? 'Transmission Type' : 'Transmissie type', detailsToUse.trans_type]);

      // Forks
      if (!detailsToUse.no_forks) {
        if (detailsToUse.fork_length_mm) technicalData.push([language === 'de' ? 'Gabellänge' : language === 'en' ? 'Fork Length' : 'Vorkenlengte', `${detailsToUse.fork_length_mm.toLocaleString(locale)} mm`]);
        if (detailsToUse.fork_width_mm) technicalData.push([language === 'de' ? 'Gabelbreite' : language === 'en' ? 'Fork Width' : 'Vorkenbreedte', `${detailsToUse.fork_width_mm.toLocaleString(locale)} mm`]);
        if (detailsToUse.fork_height_mm) technicalData.push([language === 'de' ? 'Gabeldicke' : language === 'en' ? 'Fork Thickness' : 'Vorkendikte', `${detailsToUse.fork_height_mm.toLocaleString(locale)} mm`]);
      }

      // Hydraulics
      if (detailsToUse.hydraulic_lines) technicalData.push([language === 'de' ? 'Hydraulikleitungen' : language === 'en' ? 'Hydraulic Lines' : 'Hydraulische leidingen', detailsToUse.hydraulic_lines.toString()]);

      // Tires
      if (detailsToUse.tire_size_front) technicalData.push([language === 'de' ? 'Vorderreifen' : language === 'en' ? 'Front Tires' : 'Voorbanden', detailsToUse.tire_size_front]);
      if (detailsToUse.tire_size_back) technicalData.push([language === 'de' ? 'Hinterreifen' : language === 'en' ? 'Rear Tires' : 'Achterbanden', detailsToUse.tire_size_back]);
      if (detailsToUse.tire_type) technicalData.push([language === 'de' ? 'Reifentyp' : language === 'en' ? 'Tire Type' : 'Bandentype', detailsToUse.tire_type]);

      // Fifth wheel height (Terminal Tractor specific)
      if (detailsToUse.fifth_wheel_height_mm) technicalData.push([language === 'de' ? 'Sattelkupplung Höhe' : language === 'en' ? 'Fifth Wheel Height' : 'Schotelhoogte', `${detailsToUse.fifth_wheel_height_mm.toLocaleString(locale)} mm`]);

      // Attachment
      if (detailsToUse.attachment && detailsToUse.attachment !== 'No attachment') {
        technicalData.push([language === 'de' ? 'Anbaugerät' : language === 'en' ? 'Attachment' : 'Aanbouwdeel', detailsToUse.attachment]);
        if (detailsToUse.attachment_other) technicalData.push([language === 'de' ? 'Anbaugerät Details' : language === 'en' ? 'Attachment Details' : 'Aanbouwdeel details', detailsToUse.attachment_other]);
      }

      if (technicalData.length > 0) {
        autoTable(doc, {
          startY: yPosition,
          head: [],
          body: technicalData,
          theme: 'plain',
          styles: {
            fontSize: 9,
            cellPadding: 2,
          },
          columnStyles: {
            0: { fontStyle: 'bold', textColor: [71, 85, 105], cellWidth: 60 },
            1: { textColor: [15, 23, 42] },
          },
        });

        yPosition = (doc as any).lastAutoTable.finalY + 15;
      }
    }

    if (photos && photos.length > 0) {
      doc.addPage();
      yPosition = 20;

      doc.setFontSize(16);
      doc.setTextColor(15, 23, 42);
      doc.text(t.photos, 20, yPosition);
      yPosition += 10;

      const imagePromises = photos.map(async (photo: Photo) => {
        try {
          const { data } = supabase.storage
            .from('dossier-photos')
            .getPublicUrl(photo.storage_path);

          const response = await fetch(data.publicUrl);
          const blob = await response.blob();
          const dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });

          const compressed = await compressImage(dataUrl);
          return compressed;
        } catch (error) {
          console.error('Error loading photo:', error);
          return null;
        }
      });

      const imageDataUrls = await Promise.all(imagePromises);
      const validImages = imageDataUrls.filter(url => url !== null) as string[];

      let xPos = 20;
      let yPos = Math.max(yPosition, 25);
      const imageWidth = 80;
      const imageHeight = 60;
      const spacing = 10;
      const footerStartY = 282;
      const maxYForImages = footerStartY - imageHeight - 10;
      let imagesInRow = 0;

      validImages.forEach((imageData, index) => {
        if (imagesInRow === 2) {
          xPos = 20;
          yPos += imageHeight + spacing;
          imagesInRow = 0;
        }

        if (yPos > maxYForImages) {
          doc.addPage();
          yPos = 25;
          xPos = 20;
          imagesInRow = 0;
        }

        try {
          doc.addImage(imageData, 'JPEG', xPos, yPos, imageWidth, imageHeight);
        } catch (error) {
          console.error('Error adding image to PDF:', error);
        }

        xPos += imageWidth + spacing;
        imagesInRow++;
      });
    }

    addFooter(doc, compressedLogo || undefined);

    const termsFilename = language === 'de'
      ? '/verkoopvoorwaarden_de.pdf'
      : language === 'en'
      ? '/terms_and_conditions_of_sales_uk.pdf'
      : '/verkoopvoorwaarden_nl.pdf';

    const pdfBytes = doc.output('arraybuffer');
    const mainPdfDoc = await PDFDocument.load(pdfBytes);

    try {
      const termsResponse = await fetch(termsFilename);
      const termsBytes = await termsResponse.arrayBuffer();
      const termsPdfDoc = await PDFDocument.load(termsBytes);

      const copiedPages = await mainPdfDoc.copyPages(termsPdfDoc, termsPdfDoc.getPageIndices());
      copiedPages.forEach((page) => {
        mainPdfDoc.addPage(page);
      });
    } catch (error) {
      console.error('Error loading terms and conditions:', error);
    }

    const mergedPdfBytes = await mainPdfDoc.save();
    const blob = new Blob([mergedPdfBytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);

    const brand = dossier.brand || 'Unknown';
    const model = dossier.model || 'Unknown';
    const filename = `${dossier.dossier_number}_${brand}_${model}_ext.pdf`.replace(/\s+/g, '_');

    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();

    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Error generating external PDF:', error);
    throw error;
  }
}

export async function generateCleanExternalPDF(dossierId: string, language: Language = 'nl') {
  try {
    const t = translations[language];
    const locale = language === 'de' ? 'de-DE' : language === 'en' ? 'en-GB' : 'nl-NL';
    const { data: dossier, error: dossierError } = await supabase
      .from('dossiers')
      .select(`
        *,
        user_profiles:created_by (
          full_name
        )
      `)
      .eq('id', dossierId)
      .maybeSingle();

    if (dossierError) throw dossierError;
    if (!dossier) throw new Error('Dossier niet gevonden');

    const { data: forkliftDetails } = await supabase
      .from('forklift_details')
      .select('*')
      .eq('dossier_id', dossierId)
      .maybeSingle();

    const { data: echDetails } = await supabase
      .from('empty_container_handler_details')
      .select('*')
      .eq('dossier_id', dossierId)
      .maybeSingle();

    const { data: reachstackerDetails } = await supabase
      .from('reachstacker_details')
      .select('*')
      .eq('dossier_id', dossierId)
      .maybeSingle();

    const { data: terminalTractorDetails } = await supabase
      .from('terminal_tractor_details')
      .select('*')
      .eq('dossier_id', dossierId)
      .maybeSingle();

    const { data: photos } = await supabase
      .from('photos')
      .select('*')
      .eq('dossier_id', dossierId)
      .eq('visible_online', true)
      .order('display_order', { ascending: true })
      .order('created_at', { ascending: true });

    const doc = new jsPDF();
    let yPosition = 20;

    doc.setFontSize(28);
    doc.setTextColor(15, 23, 42);
    const brandModel = `${dossier.brand || ''} ${dossier.model || ''}`.trim();
    doc.text(brandModel, 20, yPosition);
    yPosition += 15;

    const frontPhoto = photos?.find(p =>
      p.category?.toLowerCase().includes('voorkant') ||
      p.category?.toLowerCase().includes('front')
    ) || photos?.[0];

    if (frontPhoto) {
      try {
        const { data } = supabase.storage
          .from('dossier-photos')
          .getPublicUrl(frontPhoto.storage_path);

        const response = await fetch(data.publicUrl);
        const blob = await response.blob();
        const dataUrl = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.onerror = reject;
          reader.readAsDataURL(blob);
        });

        const compressedPhoto = await compressImage(dataUrl);

        const imageWidth = 170;
        const imageHeight = 120;
        const imageX = 20;

        doc.addImage(compressedPhoto, 'JPEG', imageX, yPosition, imageWidth, imageHeight);
        yPosition += imageHeight + 10;
      } catch (error) {
        console.error('Error loading front photo:', error);
      }
    }

    const detailsToUse = forkliftDetails || echDetails || reachstackerDetails || terminalTractorDetails;

    if (detailsToUse) {
      doc.setFontSize(16);
      doc.setTextColor(15, 23, 42);
      doc.text(t.technicalSpecs, 20, yPosition);
      yPosition += 10;

      const technicalData: string[][] = [];
      const hoursUnit = language === 'de' ? 'Std.' : language === 'en' ? 'hrs' : 'uur';
      const yesNo = (value: boolean | undefined) => {
        if (value === undefined || value === null) return '';
        return value ? (language === 'de' ? 'Ja' : language === 'en' ? 'Yes' : 'Ja') : (language === 'de' ? 'Nein' : language === 'en' ? 'No' : 'Nee');
      };

      if (detailsToUse.order_no) technicalData.push([t.stockId, detailsToUse.order_no]);
      if (detailsToUse.serial_no) technicalData.push([t.serialNumber, detailsToUse.serial_no]);
      if (detailsToUse.brand) technicalData.push([t.brand, detailsToUse.brand]);
      if (detailsToUse.type) technicalData.push([t.model, detailsToUse.type]);
      if (detailsToUse.year_of_manufacture) technicalData.push([t.buildYear, detailsToUse.year_of_manufacture.toString()]);
      if (detailsToUse.power) technicalData.push([language === 'de' ? 'Antrieb' : language === 'en' ? 'Power' : 'Aandrijving', detailsToUse.power]);

      if (detailsToUse.capacity_kg) technicalData.push([t.capacity, `${detailsToUse.capacity_kg.toLocaleString(locale)} kg`]);
      if (detailsToUse.load_center_mm) technicalData.push([t.loadCenter, `${detailsToUse.load_center_mm.toLocaleString(locale)} mm`]);
      if (detailsToUse.hours_on_clock) technicalData.push([t.readRunningHours, `${detailsToUse.hours_on_clock.toLocaleString(locale)} ${hoursUnit}`]);

      if (detailsToUse.mast) technicalData.push([t.mast, detailsToUse.mast]);
      if (detailsToUse.mast_type) technicalData.push([language === 'de' ? 'Masttyp' : language === 'en' ? 'Mast Type' : 'Masttype', detailsToUse.mast_type]);
      if (detailsToUse.free_lift) technicalData.push([language === 'de' ? 'Freihub' : language === 'en' ? 'Free Lift' : 'Vrijheffing', detailsToUse.free_lift]);
      if (detailsToUse.lift_height_mm) technicalData.push([t.liftHeight, `${detailsToUse.lift_height_mm.toLocaleString(locale)} mm`]);

      if (detailsToUse.length_total_mm) technicalData.push([language === 'de' ? 'Gesamtlänge' : language === 'en' ? 'Total Length' : 'Totale lengte', `${detailsToUse.length_total_mm.toLocaleString(locale)} mm`]);
      if (detailsToUse.width_total_mm) technicalData.push([language === 'de' ? 'Gesamtbreite' : language === 'en' ? 'Total Width' : 'Totale breedte', `${detailsToUse.width_total_mm.toLocaleString(locale)} mm`]);
      if (detailsToUse.drive_through_height_mm) technicalData.push([language === 'de' ? 'Durchfahrtshöhe' : language === 'en' ? 'Drive-through Height' : 'Doorrijhoogte', `${detailsToUse.drive_through_height_mm.toLocaleString(locale)} mm`]);
      if (detailsToUse.serviceweight_kg) technicalData.push([language === 'de' ? 'Eigengewicht' : language === 'en' ? 'Service Weight' : 'Eigen gewicht', `${detailsToUse.serviceweight_kg.toLocaleString(locale)} kg`]);

      if (detailsToUse.cabin_type) technicalData.push([t.cabinType, detailsToUse.cabin_type]);
      if (detailsToUse.heater !== undefined && detailsToUse.heater !== null) technicalData.push([language === 'de' ? 'Heizung' : language === 'en' ? 'Heater' : 'Verwarming', yesNo(detailsToUse.heater)]);
      if (detailsToUse.airco !== undefined && detailsToUse.airco !== null) technicalData.push([language === 'de' ? 'Klimaanlage' : language === 'en' ? 'Air Conditioning' : 'Airconditioning', yesNo(detailsToUse.airco)]);

      if (detailsToUse.seat_brand) technicalData.push([language === 'de' ? 'Sitzmarke' : language === 'en' ? 'Seat Brand' : 'Stoelmerk', detailsToUse.seat_brand]);
      if (detailsToUse.seat_type_suspension) technicalData.push([language === 'de' ? 'Sitzfederung' : language === 'en' ? 'Seat Suspension' : 'Stoelvering', detailsToUse.seat_type_suspension]);

      if (detailsToUse.engine_brand) technicalData.push([t.engineBrand, detailsToUse.engine_brand]);
      if (detailsToUse.engine_type) technicalData.push([t.engineType, detailsToUse.engine_type]);
      if (detailsToUse.adblue !== undefined && detailsToUse.adblue !== null) technicalData.push(['AdBlue', yesNo(detailsToUse.adblue)]);

      if (detailsToUse.front_axle_brand) technicalData.push([language === 'de' ? 'Vorderachsmarke' : language === 'en' ? 'Front Axle Brand' : 'Vooras merk', detailsToUse.front_axle_brand]);
      if (detailsToUse.front_axle_type) technicalData.push([language === 'de' ? 'Vorderachstyp' : language === 'en' ? 'Front Axle Type' : 'Vooras type', detailsToUse.front_axle_type]);
      if (detailsToUse.trans_brand) technicalData.push([language === 'de' ? 'Getriebemarke' : language === 'en' ? 'Transmission Brand' : 'Transmissie merk', detailsToUse.trans_brand]);
      if (detailsToUse.trans_type) technicalData.push([language === 'de' ? 'Getriebetyp' : language === 'en' ? 'Transmission Type' : 'Transmissie type', detailsToUse.trans_type]);

      if (!detailsToUse.no_forks) {
        if (detailsToUse.fork_length_mm) technicalData.push([language === 'de' ? 'Gabellänge' : language === 'en' ? 'Fork Length' : 'Vorkenlengte', `${detailsToUse.fork_length_mm.toLocaleString(locale)} mm`]);
        if (detailsToUse.fork_width_mm) technicalData.push([language === 'de' ? 'Gabelbreite' : language === 'en' ? 'Fork Width' : 'Vorkenbreedte', `${detailsToUse.fork_width_mm.toLocaleString(locale)} mm`]);
        if (detailsToUse.fork_height_mm) technicalData.push([language === 'de' ? 'Gabeldicke' : language === 'en' ? 'Fork Thickness' : 'Vorkendikte', `${detailsToUse.fork_height_mm.toLocaleString(locale)} mm`]);
      }

      if (detailsToUse.hydraulic_lines) technicalData.push([language === 'de' ? 'Hydraulikleitungen' : language === 'en' ? 'Hydraulic Lines' : 'Hydraulische leidingen', detailsToUse.hydraulic_lines.toString()]);

      if (detailsToUse.tire_size_front) technicalData.push([language === 'de' ? 'Vorderreifen' : language === 'en' ? 'Front Tires' : 'Voorbanden', detailsToUse.tire_size_front]);
      if (detailsToUse.tire_size_back) technicalData.push([language === 'de' ? 'Hinterreifen' : language === 'en' ? 'Rear Tires' : 'Achterbanden', detailsToUse.tire_size_back]);
      if (detailsToUse.tire_type) technicalData.push([language === 'de' ? 'Reifentyp' : language === 'en' ? 'Tire Type' : 'Bandentype', detailsToUse.tire_type]);

      if (detailsToUse.fifth_wheel_height_mm) technicalData.push([language === 'de' ? 'Sattelkupplung Höhe' : language === 'en' ? 'Fifth Wheel Height' : 'Schotelhoogte', `${detailsToUse.fifth_wheel_height_mm.toLocaleString(locale)} mm`]);

      if (detailsToUse.attachment && detailsToUse.attachment !== 'No attachment') {
        technicalData.push([language === 'de' ? 'Anbaugerät' : language === 'en' ? 'Attachment' : 'Aanbouwdeel', detailsToUse.attachment]);
        if (detailsToUse.attachment_other) technicalData.push([language === 'de' ? 'Anbaugerät Details' : language === 'en' ? 'Attachment Details' : 'Aanbouwdeel details', detailsToUse.attachment_other]);
      }

      if (technicalData.length > 0) {
        autoTable(doc, {
          startY: yPosition,
          head: [],
          body: technicalData,
          theme: 'plain',
          styles: {
            fontSize: 9,
            cellPadding: 2,
          },
          columnStyles: {
            0: { fontStyle: 'bold', textColor: [71, 85, 105], cellWidth: 60 },
            1: { textColor: [15, 23, 42] },
          },
        });

        yPosition = (doc as any).lastAutoTable.finalY + 15;
      }
    }

    if (photos && photos.length > 0) {
      doc.addPage();
      yPosition = 20;

      doc.setFontSize(16);
      doc.setTextColor(15, 23, 42);
      doc.text(t.photos, 20, yPosition);
      yPosition += 10;

      const imagePromises = photos.map(async (photo: Photo) => {
        try {
          const { data } = supabase.storage
            .from('dossier-photos')
            .getPublicUrl(photo.storage_path);

          const response = await fetch(data.publicUrl);
          const blob = await response.blob();
          const dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });

          const compressed = await compressImage(dataUrl);
          return compressed;
        } catch (error) {
          console.error('Error loading photo:', error);
          return null;
        }
      });

      const imageDataUrls = await Promise.all(imagePromises);
      const validImages = imageDataUrls.filter(url => url !== null) as string[];

      let xPos = 20;
      let yPos = Math.max(yPosition, 25);
      const imageWidth = 80;
      const imageHeight = 60;
      const spacing = 10;
      const maxYForImages = 280;
      let imagesInRow = 0;

      validImages.forEach((imageData) => {
        if (imagesInRow === 2) {
          xPos = 20;
          yPos += imageHeight + spacing;
          imagesInRow = 0;
        }

        if (yPos > maxYForImages) {
          doc.addPage();
          yPos = 25;
          xPos = 20;
          imagesInRow = 0;
        }

        try {
          doc.addImage(imageData, 'JPEG', xPos, yPos, imageWidth, imageHeight);
        } catch (error) {
          console.error('Error adding image to PDF:', error);
        }

        xPos += imageWidth + spacing;
        imagesInRow++;
      });
    }

    const pdfBytes = doc.output('arraybuffer');
    const blob = new Blob([pdfBytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);

    const brand = dossier.brand || 'Unknown';
    const model = dossier.model || 'Unknown';
    const filename = `${dossier.dossier_number}_${brand}_${model}_clean.pdf`.replace(/\s+/g, '_');

    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();

    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Error generating clean external PDF:', error);
    throw error;
  }
}
