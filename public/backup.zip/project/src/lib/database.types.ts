export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      dossiers: {
        Row: {
          id: string
          dossier_number: string
          dossier_datum: string
          title: string
          description: string
          equipment_type: string
          brand: string
          model: string
          year: number | null
          condition: string
          location: string
          estimated_value: number | null
          status: string
          created_by: string
          assigned_to: string | null
          created_at: string
          updated_at: string
          merk: string
          type: string
          bouwjaar: number | null
          serienummer: string | null
          uren: number | null
          capaciteit: number | null
          hefhoogte: number | null
          verkoopdatum: string | null
          land: string | null
          locatie: string | null
          is_marktdata: boolean
          brandstof: string | null
          lastzwaartepunt: number | null
          vrije_hef: number | null
          masttype: string | null
          aanbouwdeel: string | null
          purchase_price: number | null
          handelsprijs: number | null
          eindklantprijs: number | null
          sale_price: number | null
          sold_at: string | null
          sold_via_platform: string | null
          customer_name: string | null
          latitude: number | null
          longitude: number | null
        }
        Insert: {
          id?: string
          dossier_number?: string
          dossier_datum?: string
          title: string
          description?: string
          equipment_type: string
          brand?: string
          model?: string
          year?: number | null
          condition?: string
          location?: string
          estimated_value?: number | null
          status?: string
          created_by: string
          assigned_to?: string | null
          created_at?: string
          updated_at?: string
          merk?: string
          type?: string
          bouwjaar?: number | null
          serienummer?: string | null
          uren?: number | null
          capaciteit?: number | null
          hefhoogte?: number | null
          verkoopdatum?: string | null
          land?: string | null
          locatie?: string | null
          is_marktdata?: boolean
          brandstof?: string | null
          lastzwaartepunt?: number | null
          vrije_hef?: number | null
          masttype?: string | null
          aanbouwdeel?: string | null
          purchase_price?: number | null
          handelsprijs?: number | null
          eindklantprijs?: number | null
          sale_price?: number | null
          sold_at?: string | null
          sold_via_platform?: string | null
          customer_name?: string | null
          latitude?: number | null
          longitude?: number | null
        }
        Update: {
          id?: string
          dossier_number?: string
          dossier_datum?: string
          title?: string
          description?: string
          equipment_type?: string
          brand?: string
          model?: string
          year?: number | null
          condition?: string
          location?: string
          estimated_value?: number | null
          status?: string
          created_by?: string
          assigned_to?: string | null
          created_at?: string
          updated_at?: string
          merk?: string
          type?: string
          bouwjaar?: number | null
          serienummer?: string | null
          uren?: number | null
          capaciteit?: number | null
          hefhoogte?: number | null
          verkoopdatum?: string | null
          land?: string | null
          locatie?: string | null
          is_marktdata?: boolean
          brandstof?: string | null
          lastzwaartepunt?: number | null
          vrije_hef?: number | null
          masttype?: string | null
          aanbouwdeel?: string | null
          purchase_price?: number | null
          handelsprijs?: number | null
          eindklantprijs?: number | null
          sale_price?: number | null
          sold_at?: string | null
          sold_via_platform?: string | null
          customer_name?: string | null
          latitude?: number | null
          longitude?: number | null
        }
      }
      dossier_attachments: {
        Row: {
          id: string
          dossier_id: string
          file_name: string
          file_path: string
          file_type: string
          file_size: number
          uploaded_by: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          dossier_id: string
          file_name: string
          file_path: string
          file_type: string
          file_size: number
          uploaded_by: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          dossier_id?: string
          file_name?: string
          file_path?: string
          file_type?: string
          file_size?: number
          uploaded_by?: string
          created_at?: string
          updated_at?: string
        }
      }
      user_profiles: {
        Row: {
          id: string
          email: string
          full_name: string
          role: string
          active: boolean
          dealer_id: string | null
          language_preference: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string
          role?: string
          active?: boolean
          dealer_id?: string | null
          language_preference?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string
          role?: string
          active?: boolean
          dealer_id?: string | null
          language_preference?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      dealers: {
        Row: {
          id: string
          company_name: string
          contact_person: string
          email: string
          phone: string | null
          address: string | null
          city: string | null
          country: string | null
          notes: string | null
          active: boolean
          created_by: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          company_name: string
          contact_person: string
          email: string
          phone?: string | null
          address?: string | null
          city?: string | null
          country?: string | null
          notes?: string | null
          active?: boolean
          created_by: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          company_name?: string
          contact_person?: string
          email?: string
          phone?: string | null
          address?: string | null
          city?: string | null
          country?: string | null
          notes?: string | null
          active?: boolean
          created_by?: string
          created_at?: string
          updated_at?: string
        }
      }
      bids: {
        Row: {
          id: string
          dossier_id: string
          dealer_id: string | null
          bedrag: number | null
          verkoopprijs: number | null
          opmerkingen: string | null
          status: string
          invitation_token: string | null
          submitted_at: string | null
          created_by: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          dossier_id: string
          dealer_id?: string | null
          bedrag?: number | null
          verkoopprijs?: number | null
          opmerkingen?: string | null
          status?: string
          invitation_token?: string | null
          submitted_at?: string | null
          created_by: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          dossier_id?: string
          dealer_id?: string | null
          bedrag?: number | null
          verkoopprijs?: number | null
          opmerkingen?: string | null
          status?: string
          invitation_token?: string | null
          submitted_at?: string | null
          created_by?: string
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}
